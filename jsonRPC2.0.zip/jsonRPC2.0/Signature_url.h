//
//  Signature_url.h
//  Signature
//
//  Created by linzh on 15/7/2.
//  Copyright (c) 2015年 linzh. All rights reserved.
//

#ifndef Signature_Signature_url_h
#define Signature_Signature_url_h

#define SuppressPerformSelectorLeakWarning(Stuff) \
 do{ \
    _Pragma("clang diagnostic push")\
    _Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\" ") \
    Stuff;\
    _Pragma("clang diagnostic pop") \
}while (0)


#define ServerAddress @"econtract.eseals.cn"
#define RpcUrl @"/econtract/jsonrpc.action?classParam="

#define Jsrpc @"jsonrpc://"



#endif