//
//  MyUrlRequest.h
//  Signature
//
//  Created by linzh on 15/7/2.
//  Copyright (c) 2015年 linzh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyUrlRequest : NSObject
@property(nonatomic,copy)NSString *urlStr;
@property(nonatomic,copy)NSArray *paramsArr;
@property(nonatomic,copy)NSString *path;
@property(nonatomic,copy)void (^successBlock)(id successJsonData);
@property(nonatomic,copy)void (^errorBlock)(int code,NSString *errorJsonData);
-(void)postStartRequest;
@end
