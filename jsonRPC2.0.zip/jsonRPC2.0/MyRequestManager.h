//
//  MyRequestManager.h
//  Signature
//
//  Created by linzh on 15/7/2.
//  Copyright (c) 2015年 linzh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyRequestManager : NSObject

+(void)postRequestWithUrl:(NSString *)urlString paramsArray:(NSArray *)params methodPath:(NSString *)path successBlock:(void(^)(id successJsonData))successBlock errorBlock:(void(^)(int code,NSString *errorJsonData))errorBlock;


+(BOOL)areadyHandle:(int)code;

@end
