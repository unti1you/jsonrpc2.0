//
//  MyUrlRequest.m
//  Signature
//
//  Created by linzh on 15/7/2.
//  Copyright (c) 2015年 linzh. All rights reserved.
//

#import "MyUrlRequest.h"
#import "JSONKit.h"
#import "AFHTTPRequestOperationManager.h"
#import "SVProgressHUD.h"
@implementation MyUrlRequest
-(id)init
{
    if (self = [super init]){
    }
    return self;
}

-(void)postStartRequest
{
    //[SVProgressHUD showWithStatus:@"正在加载……" maskType:SVProgressHUDMaskTypeClear];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    //申明返回的结果是json类型
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    //申明请求的数据是json类型
    manager.requestSerializer=[AFJSONRequestSerializer serializer];
    //如果报接受类型不一致请替换一致text/javascript或别的
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/javascript"];
    //传入的参数
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"2.0",@"jsonrpc",@"0",@"id",self.path,@"method",self.paramsArr,@"params", nil];
//    NSLog(@"--dic---%@",dic);
    [manager POST:self.urlStr parameters:dic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if([responseObject valueForKey:@"error"])
        {
            NSDictionary *errDic= [responseObject valueForKey:@"error"];
            self.errorBlock([[errDic valueForKey:@"code"] intValue],[errDic valueForKey:@"message"]);
        }else
        {
            self.successBlock([responseObject valueForKey:@"result"]);
           // [SVProgressHUD dismiss];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error = %@",error);
        //没有网络的时候会走这里
        if (error.code == -1009) {
            [SVProgressHUD showErrorWithStatus:@"网络连接错误"];
        }else
        {
            [SVProgressHUD showErrorWithStatus:[error localizedDescription]];
        }
    }];
  
}

@end
