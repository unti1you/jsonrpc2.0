//
//  MyRequestManager.m
//  Signature
//
//  Created by linzh on 15/7/2.
//  Copyright (c) 2015年 linzh. All rights reserved.
//

#import "MyRequestManager.h"
#import "MyUrlRequest.h"
#import "Signature_url.h"

@implementation MyRequestManager

+(void)postRequestWithUrl:(NSString *)urlString
              paramsArray:(NSArray *)params
               methodPath:(NSString *)path
             successBlock:(void(^)(id successJsonData))successBlock
               errorBlock:(void(^)(int code,NSString *errorJsonData))errorBlock
{
    MyUrlRequest *request = [[MyUrlRequest alloc] init];
    request.urlStr = [[NSString stringWithFormat:@"http://%@%@",ServerAddress,RpcUrl] stringByAppendingString:urlString];
    NSLog(@"___request.urlStr____ = %@",request.urlStr);
    request.successBlock = successBlock;
    request.errorBlock = errorBlock;
    request.path = path;
    request.paramsArr = params;
    [request postStartRequest];
}


+(BOOL)areadyHandle:(int)code
{
    if(code == -1)
    {
        return YES;
    }else
    {
        return NO;
    }
}
@end
